from dataclasses import dataclass
from os import environ
import re
import json, requests
import boto3, base64
from jose import jwt
# from dataclasses import dataclass
from botocore.exceptions import ClientError
from requests import post

if not environ.get('LAMBDA_RUNTIME_DIR'):
    import glob
    import sys
    dirs = glob.glob('**/', recursive=True)
    for dir in dirs:
        sys.path.append(dir)
# from modules.userManagementService.utility import add_dirs_to_path
# add_dirs_to_path()
# print(sys.path)
# from ..layers import metrics_manager
from modules.layers import logger, utils, auth_manager
from boto3.dynamodb.conditions import Key
from aws_lambda_powertools import Tracer
tracer = Tracer()
from modules.userManagementService.identity_provider import cognito_idp , cloudwatch_idp 
# from modules.labManagement.notification import SNS
from uuid import uuid4

requests_sess = requests.Session()

client = boto3.client('cognito-idp', region_name=environ['region'])    
dynamodb = boto3.resource('dynamodb')
table_tenant_user_map = dynamodb.Table('ServerlessSaaS-TenantUserMapping')
table_tenant_details = dynamodb.Table('ServerlessSaaS-TenantDetails')

env = environ['env']
saas_origin = [f"https://saas.{env}.cloudkida.com", "https://saas.cloudkida.com/", "https://saas.cloudkida.com"]
site_origin = ['http://localhost:3000', f'https://{env}.cloudkida.com']+saas_origin

# saas_origin = [f"https://saas.{env}.cloudkida.com", f"https://saas.{env}.cloudkida.com/login"]
# site_origin = ['http://localhost:3000', f'https://{env}.cloudkida.com', f'https://{env}.cloudkida.com']+saas_origin

newtest = ['http://localhost:3001']

class InvalidUserType(Exception):
    pass

class InvalidTenantId(Exception):
    pass

class Microservice():
    UserManagement = 'UserManagement'

@tracer.capture_lambda_handler
#tenant admin can create users
#Backend APIs are only working with username,So here we took email as username
def create_user(event, context):
    """users Register themself."""
    logger.info("Request Got")
    utils.set_header(event)

    tenant_id = environ['TenantId']
    tenant_name = "default"
    user_pool_id=environ['CognitoUserPoolId']
    client_id=environ['CognitoAppClientId']

    # isTenantSignUp = False
    if 'origin' in event['headers']:
        if event['headers']['origin'] not in site_origin:
            sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]
            
            print("Origin : ", event['headers']['origin'])
            if event['headers']['origin'] == 'https://cloudkida.electromech.info' :
                sub_domain = 'cloudkida'
            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

            isTenantSignUp = True
            tenant_id, user_pool_id, client_id, tenant_name = get_tenant_client(sub_domain)

    user_details = json.loads(event['body'])

    firstName = user_details['firstName']
    lastName = user_details['lastName']
    useremail = user_details['userEmail']
    addressLine = user_details['addressLine']
    city = user_details['city']
    state = user_details['state']
    country = user_details['country']
    pincode = user_details['pincode']
    mobileno = user_details['mobileno']

    logger.info('Request received to create new user')

    isValid = user_info_validation(firstName, lastName, useremail, addressLine, city, state, country, pincode, mobileno)
    if isValid[0] == False:
        logger.info("User info validation failed")
        return utils.create_error_response(isValid[1])

    # logger.log_with_tenant_context(event, "Request received to create new user")  

    user_id = str(uuid4())
        # metrics_manager.record_metric(event, "UserCreated", "Count", 1)
    try:
        user_mng = cognito_idp()
        user_mng.admin_create_user(useremail, user_pool_id, firstName, lastName, tenant_id, addressLine, city, state, country, pincode, mobileno, user_id)

        tracer.put_annotation(key="UserName", value=useremail)
        tracer.put_annotation(key="TenantId", value=tenant_id)
        tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

        logger.info("new user {} created ".format(useremail))
        # logger.log_with_tenant_context(event, response)
        # user_mgmt = UserManagement()
        # response_mapping = user_mgmt.create_user_tenant_mapping(useremail, tenant_id)

        # logger.log_with_tenant_context(event, "Request completed to create new user ")

        # metric_mng = cloudwatch_idp()
        # nameSpace='CreateAccount'
        # matricName='SignUp'
        # # dim_name='UserPool'
        # dim_name="TenantName"
        # dim_value=tenant_name
        # metric_mng.put_metric_data(nameSpace,matricName,dim_name,dim_value)
        CreateUserConsentAPI = environ['CreateUserConsentAPI']
        response = requests_sess.post(url=CreateUserConsentAPI,
                                    data=json.dumps({
                                                "tenantId": tenant_id,
                                                "userId":  user_id,
                                                "userName": useremail
                                            })
                                    )

        if response.status_code != 200 :
            logger.error(response.json())
            return utils.create_error_response()

        return utils.create_success_response("New user "+ str(firstName) +" "+ str(lastName) +" created")

    except ClientError as e:
        logger.info(e.response)

        if e.response['Error']['Code'] == 'UsernameExistsException':
            return utils.create_conflict_response("The email id already in use.")

        return utils.create_error_response()
    # else:
    # logger.log_with_tenant_context(event, "Request completed as unauthorized. Only tenant admin or system admin can create user!")        
    # return utils.create_unauthorized_response()

@tracer.capture_lambda_handler
def create_account_metric_widget(event, context):
    utils.set_header(event)
    
    user_role = event['requestContext']['authorizer']['userRole']
    tenant_name = event['requestContext']['authorizer']['tenantName']
    # user_pool_id="ap-south-1_wBWqV5JIH"
    # user_pool_id=environ['CognitoUserPoolId']
    user_details = json.loads(event['body'])
    start_datetime = user_details['StartTime']
    end_datetime = user_details['EndTime']

    if (auth_manager.isTenantAdmin(user_role)) or (auth_manager.isSystemAdmin(user_role)):
        try:
            metric_mng = cloudwatch_idp()
            resp=metric_mng.get_metric_widget_image(tenant_name, start_datetime, end_datetime)
            matric=resp['MetricWidgetImage']
            
            base64_bytes = base64.b64encode(matric)
            base64_str = base64_bytes.decode('utf-8')
            
            return utils.create_success_response_cus_body(json.dumps({"message":"Create Account Metric Fetched","metric":base64_str}))

        except ClientError as e:
            subject="Error : Create Account Metric Widget"
            message=json.dumps(e)
            utils.developerNotification(event, subject, message)
            logger.error(e)

            return utils.create_error_response()
    else:
        return utils.create_unauthorized_response()

@tracer.capture_lambda_handler
def admin_resend_user_password(event, context):
    utils.set_header(event)
    

    user_details = json.loads(event['body'])
    useremail = user_details['useremail']

    isTenantLogin = False
    try:
        user_mng = cognito_idp()
        user_mng.user_pool_id = environ['CognitoUserPoolId']
    
        if 'origin' in event['headers']:
            if event['headers']['origin'] not in site_origin:
                sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]
                isTenantLogin = True

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'
    
        if isTenantLogin:
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)
            user_mng.user_pool_id = tenant_pool_id

        user_mng.admin_resend_password(useremail)

        tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

        return utils.create_success_response("Password Resended for "+ str(useremail) +" Successfull")
    
    except ClientError as e:
        logger.info(e)
        return utils.create_error_response(message=e.response['Error']['Message'])


@tracer.capture_lambda_handler
def tenant_admin_create_user(event, context):
    """Create user by TenantAdmin"""
    utils.set_header(event)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    user_pool_id = event['requestContext']['authorizer']['userPoolId']    
    user_role = event['requestContext']['authorizer']['userRole']

    user_details = json.loads(event['body'])
    
    firstName = user_details['firstName']
    lastName = user_details['lastName']
    useremail = user_details['userEmail']
    username = useremail
    userrole = user_details['userRole']
    addressLine = user_details['addressLine']
    city = user_details['city']
    state = user_details['state']
    country = user_details['country']
    pincode = user_details['pincode']
    mobileno = user_details['mobileno']

    user_name = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=user_name)

    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    logger.log_with_tenant_context(event, "Request received by tenant admin to create new user")

    isValid = user_info_validation(firstName, lastName, useremail, addressLine, city, state, country, pincode, mobileno)
    if isValid[0] == False:
        logger.info("User info validation failed")
        return utils.create_error_response(isValid[1])

    # check whether the email domain is valid or not (disallow use of temporary mail)
    # valid_domains = ['electromech.info', 'gmail.com', 'yahoo.com', 'hotmail.com', 'live.com', 'outlook.com']
    # user, domain = useremail.split('@')

    # if domain not in valid_domains:
    #     return utils.create_error_response("Invalid email domain")

    user_tenant_id = tenant_id
    user_id = str(uuid4())
    if (auth_manager.isTenantAdmin(user_role)):
        try:
            # check new user role is valid or not
            if userrole != 'TenantAdmin' and userrole != 'TenantUser':
                raise InvalidUserType

            response = client.admin_create_user(
                Username=useremail,
                UserPoolId=user_pool_id,
                ForceAliasCreation=True,
                UserAttributes=[
                    {
                        'Name': 'email',
                        'Value': useremail
                    },
                    {
                        'Name': 'email_verified',
                        'Value': 'True'
                    },
                    {
                        'Name': 'custom:userRole',
                        'Value':  userrole,
                    },
                    {
                        'Name': 'custom:firstName',
                        'Value':  firstName,
                    },
                    {
                        'Name': 'custom:lastName',
                        'Value':  lastName,
                    },
                    {
                        'Name': 'custom:tenantId',
                        'Value': user_tenant_id
                    },
                    {
                        'Name': 'custom:addressLine',
                        'Value': addressLine
                    },
                    {
                        'Name': 'custom:city',
                        'Value': city
                    },
                    {
                        'Name': 'custom:state',
                        'Value': state
                    },
                    {
                        'Name': 'custom:country',
                        'Value': country
                    },
                    {
                        'Name': 'custom:pincode',
                        'Value': pincode
                    },
                    {
                        'Name': 'custom:mobileno',
                        'Value': mobileno
                    },
                    {
                        'Name': 'custom:userid',
                        'Value': user_id
                    }
                    # {
                    #     'Name': 'custom:policyId',
                    #     'Value': 'False'
                    # }
                ]
            )

            # user_mgmt = UserManagement()
            # response_mapping = user_mgmt.create_user_tenant_mapping(username, user_tenant_id)

            CreateUserConsentAPI = environ['CreateUserConsentAPI']
            response = requests_sess.post(url=CreateUserConsentAPI,
                                        data=json.dumps({
                                                    "tenantId": user_tenant_id,
                                                    "userId":  user_id,
                                                    "userName": useremail
                                                })
                                        )

            if response.status_code != 200 :
                logger.error(response.json())
                return utils.create_error_response()

            logger.log_with_tenant_context(event, "Request completed to create new user ")

            return utils.create_success_response("New "+ userrole +" "+ str(username ) +" created")

        except InvalidUserType as e:
            msg = "Invalid userrole :"+ userrole +" was given. Valid types are TenantAdmin and TenantUser."

            logger.log_with_tenant_context(event, msg)
            return utils.create_error_response(msg)

        except ClientError as e:
            subject="Error : Tenant Admin Create User"
            logger.error(e)
            
            message=json.dumps(e)
            utils.developerNotification(event, subject, message)

            if e.response['Error']['Code'] == 'UsernameExistsException':
                return utils.create_error_response("User already exists")
            return utils.create_error_response()
    else:
        logger.error("Unauthorised user : {}".format(user_name))
        return utils.create_unauthorized_response()


def get_attribute_verification_code(event, context):
    access_token = event['queryStringParameters']['access_token']
    id = cognito_idp()
    try:
        response = id.get_user_attribute_verification_code(access_token, 'email')
        msg="OTP sent to your email. Please verify it."
    except ClientError as e:
        msg = e.response['Error']['Message']
        return utils.create_success_response()

    body = {
        "message": msg,
    }
    response = {
        "statusCode": 200,
        "body": json.dumps(body)
    }
    return response


def verify_user_attribute(event, context):
    access_token = event['queryStringParameters']['access_token']
    code = event['queryStringParameters']['code']
    id=cognito_idp()
    try:
        id.verify_user_attribute(access_token, 'email', code)
        msg = "User email has been verified."
    except ClientError as e:
        msg = e.response['Error']['Message']

    body = {
        "message": msg,
    }
    response = {
        "statusCode": 200,
        "body": json.dumps(body)
    }
    return response


@tracer.capture_lambda_handler
def get_users(event, context):
    "Get list of all user in same tenant"
    utils.set_header(event)

    tenant_id = event['requestContext']['authorizer']['tenantId']    
    user_pool_id = event['requestContext']['authorizer']['userPoolId']    
    user_role = event['requestContext']['authorizer']['userRole']  
    users = []
    
    user_name = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=user_name)

    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value='UserManagement')
    logger.log_with_tenant_context(event, "Request received to get user")
    
    if (auth_manager.isTenantAdmin(user_role) or auth_manager.isSystemAdmin(user_role)):
        response = client.list_users(
            UserPoolId=user_pool_id
        )
        logger.log_with_tenant_context(event, response) 
        num_of_users = len(response['Users'])
        # metrics_manager.record_metric(event, "Number of users", "Count", num_of_users)
        if (num_of_users > 0):
            for user in response['Users']:
                is_same_tenant_user = False
                user_info = UserInfo()
                for attr in user["Attributes"]:
                    if(attr["Name"] == "custom:tenantId" and attr["Value"] == tenant_id):
                        is_same_tenant_user = True

                    if(attr["Name"] == "email"):
                        user_info.email = attr["Value"]
                    if attr["Name"] == "custom:userId":
                        user_info.userId = attr["Value"]
                if(is_same_tenant_user):
                    user_info.enabled = user["Enabled"]
                    user_info.created = user["UserCreateDate"]
                    user_info.modified = user["UserLastModifiedDate"]
                    user_info.status = user["UserStatus"] 
                    user_info.user_name = user["Username"]
                    users.append(user_info)                    
        
        return utils.generate_response(users)
    else:
        logger.log_with_tenant_context(event, "Request completed as unauthorized.")        
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler()
def get_user(event, context):
    utils.set_header(event)

    user_pool_id = event['requestContext']['authorizer']['userPoolId']
    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    # params = json.loads(event['body'])

    accessToken = event['headers']['accessToken']
    if (auth_manager.isTenantAdmin(user_role)) or (auth_manager.isTenantUser(user_role)):

        try:
            user_mng = cognito_idp()
            user_mng.user_pool_id = user_pool_id
            user = user_mng.get_user(accessToken)

            user_info = UserInfo()
            for attr in user["UserAttributes"]:
                # if(attr["Name"] == "custom:tenantId" and attr["Value"] == tenant_id):
                #     is_same_tenant_user = True

                if(attr["Name"] == "email"):
                    user_info.email = attr["Value"]
                if(attr["Name"] == "custom:firstName"):
                    user_info.firstName = attr["Value"]
                if(attr["Name"] == "custom:lastName"):
                    user_info.lastName = attr["Value"]
                if(attr["Name"] == "custom:addressLine"):
                    user_info.addressLine = attr["Value"]
                if(attr["Name"] == "custom:pincode"):
                    user_info.pincode = attr["Value"]
                if(attr["Name"] == "custom:city"):
                    user_info.city = attr["Value"]
                if(attr["Name"] == "custom:state"):
                    user_info.state = attr["Value"]
                if(attr["Name"] == "custom:country"):
                    user_info.country = attr["Value"]
                if(attr["Name"] == "custom:mobileno"):
                    user_info.mobileno = attr["Value"]
            # if(is_same_tenant_user):
                # user_info.enabled = user["Enabled"]
                # user_info.created = user["UserCreateDate"]
                # user_info.modified = user["UserLastModifiedDate"]
                # user_info.status = user["UserStatus"] 
            # user_info.user_name = user["Username"]

            for item in TenantUserUnneccessaryInfo:
                user_info.__dict__.pop(item)

            logger.info("User info fetched : {}".format(user_info.email))
            return utils.create_success_response_cus_body(json.dumps({"message":"fetched","userInfo":user_info.__dict__}))
        except ClientError as e:
            subject="Error : Get User"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()

@tracer.capture_lambda_handler()
def update_user(event, context):
    utils.set_header(event)
    
    # username = params['userEmail']
    
    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    params = json.loads(event['body'])

    accessToken = event['headers']['accessToken']
    firstName = params['firstName']
    lastName = params['lastName']
    addressLine = params['addressLine']
    city = params['city']
    state = params['state']
    country = params['country']
    pincode = params['pincode']
    mobileno = params['mobileno']

    if (auth_manager.isTenantAdmin(user_role)) or (auth_manager.isTenantUser(user_role)):

        try:
            user_mng = cognito_idp()
            response = user_mng.update_user_attributes(accessToken, firstName, lastName, addressLine, city, state, country, pincode, mobileno)
            logger.info("user {} updated".format(requesting_user_name))
            return utils.create_success_response("updated")
        except ClientError as e:
            subject="Error : Update User"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler()
def disable_users(event, context):
    utils.set_header(event)

    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    user_pool_id = event['requestContext']['authorizer']['userPoolId']

    params = json.loads(event['body'])

    users = params['users']

    if (auth_manager.isTenantAdmin(user_role)):

        try:
            user_mng = cognito_idp()
            user_mng.user_pool_id=user_pool_id
            for user in users:
                user_mng.admin_disable_user(user)

            logger.info("users disabled : {}".format(users))
            return utils.create_success_response("users disabled")
        except ClientError as e:
            subject="Error : Disable Users"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler()
def disable_users_all(event, context):
    utils.set_header(event)

    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    user_pool_id = event['requestContext']['authorizer']['userPoolId']

    if (auth_manager.isTenantAdmin(user_role)):

        try:
            user_mng = cognito_idp()
            user_mng.user_pool_id=user_pool_id

            def disable_user(users):
                for user in users:
                    user_mng.admin_disable_user(user['Username'])
                return True

            response = user_mng.list_users_usernames(limit=60)

            if 'Users' in response and len(response['Users'])>0:
                disable_user(response['Users'])

                if 'PaginationToken' in response:
                    HasPagination=True
                    while HasPagination:
                        response = user_mng.list_users_usernames(limit=60, pagination_token=response['PaginationToken'])
                        disable_user(response['Users'])
                        if 'PaginationToken' not in response:
                            HasPagination=False

                        logger.info("all users have been disabled ")

                return utils.create_success_response("all users have been disabled ")
            else:
                return utils.create_success_response("No users found")
        except ClientError as e:
            subject="Error : Disable All User"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler()
def enable_users(event, context):
    utils.set_header(event)
    
    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    user_pool_id = event['requestContext']['authorizer']['userPoolId']

    params = json.loads(event['body'])

    users = params['users']

    if (auth_manager.isTenantAdmin(user_role)):

        try:
            user_mng = cognito_idp()
            user_mng.user_pool_id=user_pool_id
            for user in users:
                user_mng.admin_enable_user(user)
            
            logger.info("users enabled : {}".format(users))
            return utils.create_success_response("users enabled")
        except ClientError as e:
            subject="Error : Enable Users"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler()
def enable_users_all(event, context):
    utils.set_header(event)

    user_role = event['requestContext']['authorizer']['userRole']
    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    user_pool_id = event['requestContext']['authorizer']['userPoolId']

    if (auth_manager.isTenantAdmin(user_role)):

        try:
            def enable_user(users):
                for user in users:
                    user_mng.admin_enable_user(user['Username'])
                return True

            user_mng = cognito_idp()
            user_mng.user_pool_id=user_pool_id
            
            response = user_mng.list_users_usernames(limit=60)

            if 'Users' in response and len(response['Users'])>0:
                enable_user(response['Users'])

                if 'PaginationToken' in response:
                    HasPagination=True
                    while HasPagination:
                        response = user_mng.list_users_usernames(limit=60, pagination_token=response['PaginationToken'])
                        enable_user(response['Users'])
                        if 'PaginationToken' not in response:
                            HasPagination=False

                return utils.create_success_response("all users have been enabled ")
            else:
                return utils.create_success_response("No users found")
        except ClientError as e:
            subject="Error : Enable All Users"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e.response)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(requesting_user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler
def list_users(event, context):
    utils.set_header(event)

    user_role = event['requestContext']['authorizer']['userRole']
    user_pool_id = event['requestContext']['authorizer']['userPoolId']

    user_name = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=user_name)
    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    params = json.loads(event['body'])
    limit = int(params['limit'])
    filter_str=''
    if 'filter' in params:
        filter_str = params['filter']

    if (auth_manager.isSystemAdmin(user_role)):
        user_pool_id = environ['CognitoUserPoolId']

    if (auth_manager.isSystemAdmin(user_role) or auth_manager.isTenantAdmin(user_role)):

        try:
            # response = client.list_users(
            #     UserPoolId=user_pool_id
            # )
            if int(limit) > 60 or int(limit)<1:
                return utils.create_error_response("Invalid user limit. Minimum 1 and Maximum 60 are allowed")

            user_mng = cognito_idp()
            user_mng.user_pool_id=user_pool_id
            if 'pagination_token' not in params:
                response = user_mng.list_users(limit=limit,filter_str=filter_str)
            else:
                response = user_mng.list_users(limit=limit,filter_str=filter_str,pagination_token=params['pagination_token'])

            logger.info("Users fetched by {} ".format(user_name))

            if response['Users'] and len(response['Users'])>0:
                users = list()
                for user in response['Users']:
                    for attr in user['Attributes']:

                        if attr['Name'] == 'email':
                            email = attr['Value']
                        if attr['Name'] == 'custom:firstName':
                            first_name = attr['Value']
                        if attr['Name'] == 'custom:lastName':
                            last_name = attr['Value']
                        if attr['Name'] == 'custom:userRole':
                            user_role = attr['Value']
                        if attr['Name'] == 'custom:userid':
                            user_id = attr['Value']
                    users.append({
                        'Name'              : first_name + ' ' + last_name,
                        'Email'                 : email,
                        'userId'                : user_id,
                        'userRole'              : user_role,
                        'UserCreateDate'        : str(user['UserCreateDate'])[:19],
                        'UserLastModifiedDate'  : str(user['UserLastModifiedDate'])[:19],
                        'Enabled'               : user['Enabled'],
                        'UserStatus'            : user['UserStatus'],
                    })
                body = {
                    "message"    : "Users fetched",
                    "TotalUsers" : str(user_mng.describe_user_pool()['UserPool']['EstimatedNumberOfUsers']),
                    "Users"      : users
                }
                if 'PaginationToken' in response:
                    body.update({"pagination_token":response['PaginationToken']})
                return utils.create_success_response_cus_body(json.dumps(body))
            else:
                return utils.create_notfound_response("No users found")

        except ClientError as e:
            subject="Error : List Users"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            logger.error(e)
            return utils.create_error_response()
    else:
        logger.error("user unauthorized : {}".format(user_name))
        return utils.create_unauthorized_response()


@tracer.capture_lambda_handler
def get_user_ref(event, context):
    utils.set_header(event)

    requesting_user_name = event['requestContext']['authorizer']['userName']
    tenant_id = event['requestContext']['authorizer']['tenantId']    
    user_pool_id = event['requestContext']['authorizer']['userPoolId']    
    user_role = event['requestContext']['authorizer']['userRole']    
    user_name = event['pathParameters']['username']  

    tracer.put_annotation(key="UserName", value=requesting_user_name)
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value='UserManagement')
    logger.log_with_tenant_context(event, "Request received to get user")

    if (auth_manager.isSystemAdmin(user_role)):
        user_tenant_id = event['queryStringParameters']['tenantid']
        tenant_details = table_tenant_details.get_item( 
            Key ={
                'tenantId': user_tenant_id
            }
        )
        logger.info(tenant_details)
        user_pool_id = tenant_details['Item']['userPoolId']

    if (auth_manager.isTenantUser(user_role) and user_name != requesting_user_name):        
        logger.log_with_tenant_context(event, "Request completed as unauthorized. User can only get its information.")        
        return utils.create_unauthorized_response()
    else:
        try:
            user_info = get_user_info(event, user_pool_id, user_name)
        except ClientError as e:
            subject="Error : Get User Ref"
            message=json.dumps(e.response)
            utils.developerNotification(event, subject, message)

            msg = e.response['Error']['Message']
            return utils.create_success_response(msg)
        if(user_info.tenant_id!=tenant_id):
            logger.log_with_tenant_context(event, "Request completed as unauthorized. Users in other tenants cannot be accessed")
            return utils.create_unauthorized_response()
        else:
            logger.log_with_tenant_context(event, "Request completed to get new user ")
            return utils.create_success_response(user_info.__dict__)

# @tracer.capture_lambda_handler
def update_user_ref(event, context):
    requesting_user_name = event['requestContext']['authorizer']['userName']    
    tenant_id = event['requestContext']['authorizer']['tenantId']    
    user_pool_id = event['requestContext']['authorizer']['userPoolId']    
    user_role = event['requestContext']['authorizer']['userRole']    

    user_details = json.loads(event['body'])

    user_name = event['pathParameters']['username']    


    tracer.put_annotation(key="UserName", value=requesting_user_name)
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value='UserManagement')
    logger.log_with_tenant_context(event, "Request received to get user")
   
    if (auth_manager.isSystemAdmin(user_role)):
        user_tenant_id = user_details['tenantId']
        tenant_details = table_tenant_details.get_item( 
            Key ={
                'tenantId': user_tenant_id
            }
        )
        logger.info(tenant_details)
        user_pool_id = tenant_details['Item']['userPoolId']        
    
    if (auth_manager.isTenantUser(user_role) and user_name != requesting_user_name):                
        logger.log_with_tenant_context(event, "Request completed as unauthorized. User can only update itself!")        
        return utils.create_unauthorized_response()
    else:
        user_info = get_user_info(event, user_pool_id, user_name)
        if(user_info.tenant_id!=tenant_id):
            logger.log_with_tenant_context(event, "Request completed as unauthorized. Users in other tenants cannot be accessed")
            return utils.create_unauthorized_response()
        else:
            # metrics_manager.record_metric(event, "UserUpdated", "Count", 1)            
            response = client.admin_update_user_attributes(
                Username=user_name,
                UserPoolId=user_pool_id,
                UserAttributes=[
                    {
                        'Name': 'email',
                        'Value': user_details['userEmail']
                    },
                    {
                        'Name': 'custom:userRole',
                        'Value': user_details['userRole'] 
                    }
                ]
            )
            logger.log_with_tenant_context(event, response)
            logger.log_with_tenant_context(event, "Request completed to update user ")
            return utils.create_success_response("user updated")    


@tracer.capture_lambda_handler
def disable_user_ref(event, context):
    tenant_id = event['requestContext']['authorizer']['tenantId']
    user_pool_id = event['requestContext']['authorizer']['userPoolId']    
    user_role = event['requestContext']['authorizer']['userRole']
    # user_name = event['pathParameters']['username']
    user_details = json.loads(event['body'])

    user_name = user_details['username']

    requesting_user_name = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=requesting_user_name)
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value='UserManagement')

    logger.log_with_tenant_context(event, "Request received to disable new user")

    if (auth_manager.isSystemAdmin(user_role)):
        user_tenant_id = event['queryStringParameters']['tenantid']
        tenant_details = table_tenant_details.get_item( 
            Key ={
                'tenantId': user_tenant_id
            }
        )
        logger.info(tenant_details)
        user_pool_id = tenant_details['Item']['userPoolId']

    if (auth_manager.isTenantAdmin(user_role) or auth_manager.isSystemAdmin(user_role)):
        user_info = get_user_info(event, user_pool_id, user_name)
        if(user_info.tenant_id!=tenant_id):
            logger.log_with_tenant_context(event, "Request completed as unauthorized. Users in other tenants cannot be accessed")
            return utils.create_unauthorized_response()
        else:
            # metrics_manager.record_metric(event, "UserDisabled", "Count", 1)
            response = client.admin_disable_user(
                Username=user_name,
                UserPoolId=user_pool_id
            )
        
            logger.log_with_tenant_context(event, response)
            logger.log_with_tenant_context(event, "Request completed to disable new user ")
            return utils.create_success_response("User disabled")
    else:
        logger.log_with_tenant_context(event, "Request completed as unauthorized. Only tenant admin or system admin can disable user!")        
        return utils.create_unauthorized_response()

# @tracer.capture_lambda_handler
#this method uses IAM Authorization and protected using a resource policy. This method is also invoked async
def disable_users_by_tenant(event, context):
    "Disable all users of tenant"
    logger.info("Request received to disable users by tenant")
    logger.info(event)    
    
    tenantid_to_update = event['tenantId']
    tenant_user_pool_id = event['userPoolId']
    user_role =  event['userRole']
    requesting_tenant_id = event['requestingTenantId']
    
    requesting_username = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=requesting_username)
    tracer.put_annotation(key="TenantId", value=tenantid_to_update)
    tracer.put_annotation(key="Microservice", value='UserManagement')
    
    
    if ((auth_manager.isTenantAdmin(user_role) and tenantid_to_update == requesting_tenant_id) or auth_manager.isSystemAdmin(user_role)):
        filtering_exp = Key('tenantId').eq(tenantid_to_update)
        response = table_tenant_user_map.query(KeyConditionExpression=filtering_exp)
        users = response.get('Items')
        
        for user in users:
            response = client.admin_disable_user(
                Username=user['userName'],
                UserPoolId=tenant_user_pool_id
            )
            
        logger.info(response)
        logger.info("Request completed to disable users")
        return utils.create_success_response("Users disabled")
    else:
        logger.info("Request completed as unauthorized. Only tenant admin or system admin can update!")        
        return utils.create_unauthorized_response()

# @tracer.capture_lambda_handler
#this method uses IAM Authorization and protected using a resource policy. This method is also invoked async
def enable_users_by_tenant(event, context):
    logger.info("Request received to enable users by tenant")
    logger.info(event)    
    
    
    tenantid_to_update = event['tenantId']
    tenant_user_pool_id = event['userPoolId']
    user_role =  event['userRole']
    requesting_tenant_id = event['requestingTenantId']
    
    requesting_username = event['requestContext']['authorizer']['userName']    
    tracer.put_annotation(key="UserName", value=requesting_username)
    tracer.put_annotation(key="TenantId", value=tenantid_to_update)
    tracer.put_annotation(key="Microservice", value='UserManagement')
    
    
    if (auth_manager.isSystemAdmin(user_role) or auth_manager.isSystemAdmin(user_role)):
        filtering_exp = Key('tenantId').eq(tenantid_to_update)
        response = table_tenant_user_map.query(KeyConditionExpression=filtering_exp)
        users = response.get('Items')
        
        for user in users:
            response = client.admin_enable_user(
                Username=user['userName'],
                UserPoolId=tenant_user_pool_id
            )
            
        logger.info(response)
        logger.info("Request completed to enable users")
        return utils.create_success_response("Users enables")
    else:
        logger.info("Request completed as unauthorized. Only tenant admin or system admin can update!")        
        return utils.create_unauthorized_response()

def get_user_info(event, user_pool_id, user_name):
    # metrics_manager.record_metric(event, "UserInfoRequested", "Count", 1)            
    response = client.admin_get_user(
            UserPoolId=user_pool_id,
            Username=user_name
    )
    logger.log_with_tenant_context(event, response)

    # for attr in response["UserAttributes"]:
    #     attr['Name']
    #     attr['Value']

    user_info =  UserInfo()
    user_info.user_name = response["Username"]
    user_info.created = str(response["UserCreateDate"])
    user_info.modified = str(response["UserLastModifiedDate"])
    user_info.status =response['UserStatus']
    user_info.enabled = response['Enabled']
    
    for attr in response["UserAttributes"]:
        if(attr["Name"] == "custom:tenantId"):
            user_info.tenant_id = attr["Value"]
        if(attr["Name"] == "custom:userRole"):
            user_info.user_role = attr["Value"]    
        if(attr["Name"] == "email"):
            user_info.email = attr["Value"] 
        if(attr["Name"] == "custom:country"):
            user_info.country = attr["Value"] 
        if(attr["Name"] == "custom:pincode"):
            user_info.pincode = attr["Value"] 
        if(attr["Name"] == "custom:addressLine"):
            user_info.addressLine = attr["Value"] 
        if(attr["Name"] == "custom:state"):
            user_info.state = attr["Value"] 
        if(attr["Name"] == "custom:city"):
            user_info.city = attr["Value"] 
        if(attr["Name"] == "custom:mobileno"):
            user_info.mobileno = attr["Value"] 
    logger.log_with_tenant_context(event, user_info)
    return user_info

def user_info_validation(firstName:str, lastName:str, useremail:str, addressLine:str, city:str, state:str, country:str, pincode:str, mobileno:str):
    re_common = r'^([A-Za-z]+){3,50}$'
    re_email = r'^([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+$'
    re_address = r'^([A-Za-z0-9/,-]+){7,125}$'
    re_pincode = r'^([0-9]){6}$'
    re_mobileno = r'^(([0-9]){12})|(\s{0})$'

    def validate(regular_expression, attribute):
        logger.info(attribute)
        re_ = re.compile(regular_expression)
        if re.fullmatch(re_,attribute) is None:
            return False
        return True

    if validate(re_common,firstName) is False:
        return False, "Invalid first name !"

    if validate(re_common,lastName) is False:
        return False, "Invalid last name !"

    if validate(re_email,useremail) is False:
        return False, "Invalid user mail !"

    if validate(re_address,addressLine.replace(' ','')) is False:
        return False, "Invalid address !"

    if validate(re_common,city) is False:
        return False, "Invalid city name !"

    if validate(re_common,state) is False:
        return False, "Invalid state name !"

    if validate(re_common,country) is False:
        return False, "Invalid country name !"

    if validate(re_pincode,pincode) is False:
        return False, "Invalid pincode !"

    if validate(re_mobileno,mobileno) is False:
        return False, "Invalid Mobile number !"

    return True, None

@tracer.capture_lambda_handler()
def user_login(event, context):
    utils.set_header(event)

    user_details = json.loads(event['body'])
    email = user_details['userEmail']
    password = user_details['password']

    isSystemAdmin = False
    isTenantLogin = False
    
    # Only for Development and Testing
    # if env == 'dev':
    if 'system' in user_details and user_details['system'] == True:
        isSystemAdmin=True

    saas_origin = [f"https://saas.{env}.cloudkida.com", f"https://saas.cloudkida.com/"]
    site_origin = ['http://localhost:3000', f'https://{env}.cloudkida.com']+saas_origin

    if 'origin' in event['headers'] and event['headers']['origin'] in saas_origin:
        isSystemAdmin = True

    if env == 'dev':
        if 'origin' in event['headers'] and event['headers']['origin'] in newtest:
            isTenantLogin = True
            event['headers']['origin'] = 'https://newtest.dev.cloudkida.com/'

    if 'origin' in event['headers']:
        if event['headers']['origin'] not in site_origin:
            sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

            isTenantLogin = True
    logger.info("This is a tenant login {}".format(isTenantLogin))

    try:
        # if isTenantLogin:

        user_login = cognito_idp()

        if isSystemAdmin:
            logger.info("Condition : isSystemAdmin")
            auth = user_login.init_auth(email, password, clientId=environ['SaaSAppClientId'])
        elif isTenantLogin:
            logger.info("Get tenant config : ")
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)
            logger.info("{} {}".format(tenant_pool_id, tenant_client_id))
            auth = user_login.init_auth(email, password, clientId=tenant_client_id)
            logger.info("auth : {}".format(auth))
            logger.info("Condition : isTenantLogin")
        else:
            logger.info("Condition : default tenant login")
            auth = user_login.init_auth(email, password)
    
        if 'ChallengeName' in auth :
            # print(auth)
            if 'SOFTWARE_TOKEN_MFA' in auth['ChallengeName'] :
                soft_sess = auth['Session']
                action='SOFTWARE_TOKEN_MFA'
                msg="Enter your OTP"

                logger.info("MFA login")

            elif 'NEW_PASSWORD_REQUIRED' in auth['ChallengeName'] :
                soft_sess = auth['Session']
                action='NEW_PASSWORD_REQUIRED'
                msg="Set new password."

                logger.info("User first time login")

            body = {
                "message": msg,
                "action": action,
                "session": soft_sess
            }
            return utils.create_success_response_cus_body(json.dumps(body))
        
        elif 'AuthenticationResult' in auth :
            claims = jwt.get_unverified_claims(auth['AuthenticationResult']['IdToken'])

            body = {
                "message": f"User {claims['cognito:username']} login successful.",
                "TokenType": auth['AuthenticationResult']['TokenType'],
                "AccessToken": auth['AuthenticationResult']['AccessToken'],
                "RefreshToken": auth['AuthenticationResult']['RefreshToken'],
                "IdToken": auth['AuthenticationResult']['IdToken'],
                "userRole": claims['custom:userRole'],
                "firstName": claims['custom:firstName'],
                "lastName": claims['custom:lastName'],
                "email": claims['email'],
                "isTenantLogin": isTenantLogin
                # "DeviceKey":auth['AuthenticationResult']['NewDeviceMetadata']['DeviceKey'],
                # "DeviceGroupKey":auth['AuthenticationResult']['NewDeviceMetadata']['DeviceGroupKey']
            }

            tracer.put_annotation(key="UserName", value=claims['email'])

            tenant_id = claims['custom:tenantId']
            tracer.put_annotation(key="TenantId", value=tenant_id)
            tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

            logger.info("user logged in : {}, tenant : {} ".format(email,tenant_id))

            return utils.create_success_response_cus_body(json.dumps(body))
    
    except ClientError as e:
        logger.error(e.response)

        if e.response['Error']['Code'] == 'UserNotFoundException':
            return utils.create_error_response("Incorrect username or password")
                
        if e.response['Error']['Code'] == 'NotAuthorizedException':
            return utils.create_error_response(e.response['Error']['Message'])
        
        return utils.create_error_response()


@tracer.capture_lambda_handler()
def res_to_new_password_required_chellenge(event, context):
    utils.set_header(event)

    '''Enforce password change'''
    params = json.loads(event['body'])
    session = params['session']
    username = params['userEmail']
    new_password = params['new_password']

    if len(new_password)<8:
        return utils.create_error_response("Minimum 8 characters are mandatory")
    elif re.search(r'[a-z]',new_password) is None:
        return utils.create_error_response("at least a small case alphabate is mandatory")
    elif re.search(r'[A-Z]',new_password) is None:
        return utils.create_error_response("at least a capital case alphabate is mandatory")
    elif re.search(r'[0-9]',new_password) is None:
        return utils.create_error_response("at least a digit is mandatory")
    elif re.search(r'[\^$*.\[\]{}\(\)?\-\"!@#%\/,><\':;|_~`]',new_password) is None:
        return utils.create_error_response("at least a special character is mandatory")

    isSystemAdmin = False
    isTenantLogin = False
    tenant_name = "default"

    if env == 'dev':
        if 'origin' in event['headers'] and event['headers']['origin'] in newtest:
            isTenantLogin = True
            event['headers']['origin'] = 'https://newtest.dev.cloudkida.com/'

    if  'origin' in event['headers'] and event['headers']['origin'] in saas_origin:
        isSystemAdmin = True
    
    elif 'origin' in event['headers']:
        if event['headers']['origin'] not in site_origin:
            sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

            isTenantLogin = True

    # "/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-\"!@#%&\/,><\':;|_~`])\S{8,99}$/"
    try:

        if isTenantLogin:
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)

        id = cognito_idp()
        if isSystemAdmin:
            clientId=environ['SaaSAppClientId']
            response = id.res_to_new_password_required_chellenge(session, username, new_password,clientId=clientId)
        elif isTenantLogin:
            response = id.res_to_new_password_required_chellenge(session, username, new_password,clientId=tenant_client_id)
        else:
            response = id.res_to_new_password_required_chellenge(session, username, new_password)

        if 'AuthenticationResult' in response:
            claims = jwt.get_unverified_claims(response['AuthenticationResult']['IdToken'])

            body = {
                "message": "User signed in succsessful.",
                "TokenType": response['AuthenticationResult']['TokenType'],
                "AccessToken": str(response['AuthenticationResult']['AccessToken']),
                "RefreshToken": str(response['AuthenticationResult']['RefreshToken']),
                "IdToken": str(response['AuthenticationResult']['IdToken']),
                "userRole": claims['custom:userRole'],
                "firstName": claims['custom:firstName'],
                "lastName": claims['custom:lastName'],
                "email": claims['email'],
                "isTenantLogin": isTenantLogin
                # "userName": claims['cognito:username']
            }

            # if new created user is TenantAdmin then give email subscription
            if auth_manager.isTenantAdmin(claims['custom:userRole']):
                LabCreationNotificationAPI = environ['LabCreationNotificationAPI']
                response = requests_sess.post(url=LabCreationNotificationAPI, 
                                            headers={"Authorization": "{} {}".format(body['TokenType'],body['IdToken'])},
                                            data=json.dumps({
                                                    "email": claims['email']
                                                })
                                                    )
            #     sns_mng = SNS()
            #     sns_mng.subscribe_email(claims['email'])
                
            #     logger.info("Subscription request sent for email notifications")

            # Create credit record
            if not auth_manager.isSystemAdmin(body['userRole']) :
                response = post(url=environ['userCreditAPIURL'], headers={"Authorization": "{} {}".format(body['TokenType'],body['IdToken'])})

                if response.status_code != 200 :
                    logger.error("Error in userCreditAPIURL : {}".format(response.status_code))
                    logger.error(response.json())
                    return utils.create_error_response("Something went wrong")

            tracer.put_annotation(key="UserName", value=claims['email'])

            tenant_id = claims['custom:tenantId']
            tracer.put_annotation(key="TenantId", value=tenant_id)
            tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

            # guacamole_mng = Guacamole()
            # response = guacamole_mng.create_user(username, new_password)
            
            # if response:
            #     logger.info("Guacamole user {} created".format(username))

            metric_mng = cloudwatch_idp()
            nameSpace='CreateAccount'
            matricName='SignUpSuccess'
            # dim_name='UserPool'
            dim_name="TenantName"
            dim_value=tenant_name
            metric_mng.put_metric_data(nameSpace,matricName,dim_name,dim_value)

            return utils.create_success_response_cus_body(json.dumps(body))
        
    except ClientError as e:
        logger.error(e.response)
        if e.response['Error']['Code'] == 'NotAuthorizedException':
            return utils.create_error_response_cus_body({"message":"Session is expired, login again","action":"SessionExpired"})

        return utils.create_error_response()

@tracer.capture_lambda_handler()
def verify_mfa_login(event, contest):
    utils.set_header(event)

    params = json.loads(event['body'])
    session = params['session']
    username = params['userEmail']
    mfa_code = params['mfa_code']

    isSystemAdmin = False
    isTenantLogin = False

    id = cognito_idp()
    try:

        if env == 'dev':
            if 'origin' in event['headers'] and event['headers']['origin'] in newtest:
                isTenantLogin = True
                event['headers']['origin'] = 'https://newtest.dev.cloudkida.com/'

        if 'system' in params and params['system'] == True:
            isSystemAdmin=True

        elif  'origin' in event['headers'] and event['headers']['origin'] in saas_origin:
            isSystemAdmin = True

        elif 'origin' in event['headers']:
            if event['headers']['origin'] not in site_origin:
                sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

                isTenantLogin = True

        if isSystemAdmin:
            id.client_id=environ['SaaSAppClientId']

        elif isTenantLogin:
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)
            id.client_id = tenant_client_id

        response = id.response_to_auth_challenge(session, username, mfa_code)

        if 'AuthenticationResult' in response:
            claims = jwt.get_unverified_claims(response['AuthenticationResult']['IdToken'])
            body = {
                "message": "User signed in successful.",
                "TokenType": response['AuthenticationResult']['TokenType'],
                "AccessToken": str(response['AuthenticationResult']['AccessToken']),
                "RefreshToken": str(response['AuthenticationResult']['RefreshToken']),
                "IdToken": str(response['AuthenticationResult']['IdToken']),
                "userRole": claims['custom:userRole'],
                "firstName": claims['custom:firstName'],
                "lastName": claims['custom:lastName'],
                "email": claims['email'],
                "isTenantLogin": isTenantLogin
            }

            tracer.put_annotation(key="UserName", value=claims['email'])

            tenant_id = claims['custom:tenantId']
            tracer.put_annotation(key="TenantId", value=tenant_id)
            tracer.put_annotation(key="Microservice", value='UserManagement')

            return utils.create_success_response_cus_body(json.dumps(body))
        
    except ClientError as e:
        logger.error(e.response)

        if 'CodeMismatchException' == e.response['Error']['Code']:
            return utils.create_error_response_cus_body({
                                        "message":"Invalid MFA code",
                                        "action":"CodeMismatch"
                                        })

        return utils.create_error_response()

@tracer.capture_lambda_handler()
def user_global_sign_out(event, context):
    utils.set_header(event)

    params = json.loads(event['body'])
    access_token = params['access_token']

    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    try:
        
        id = cognito_idp()
    
        response = id.global_sign_out(access_token)
    
        return utils.create_success_response("User sign out succsessful.")
    
    except ClientError as e:

        if e.response['Error']['Code'] == 'NotAuthorizedException':
            return utils.create_unauthorized_response()

        subject="Error : User Global Sign Out"
        message=json.dumps(e.response)

        utils.developerNotification(event, subject, message)
        
        logger.error(e.response)
        return utils.create_error_response()

@tracer.capture_lambda_handler()
def setup_mfa(event, context):
    utils.set_header(event)

    params = json.loads(event['body'])
    access_token = params['access_token']

    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    id = cognito_idp()
    try:
        generate_code = id.associate_soft_token(False, access_token)
        secret_code = generate_code["SecretCode"]

        body = {
            "message": "Secret key generated and add this key in Google Authenticator to get OTP.",
            "secret_code": str(secret_code)
        }
        return utils.create_success_response_cus_body(json.dumps(body))

    except ClientError as e:
        subject="Error : Setup MFA"
        message=json.dumps(e.response)
        utils.developerNotification(event, subject, message)

        logger.error(e.response)
        return utils.create_error_response()

@tracer.capture_lambda_handler()
def verify_mfa_setup(event, context):
    utils.set_header(event)

    params = json.loads(event['body'])
    access_token = params['access_token']
    mfa_code = params['mfa_code']

    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    id =cognito_idp()
    try:
        verify_token = id.verify_soft_token(False, access_token, mfa_code)
        id.set_user_mfa_preference(access_token, status=True, isPreffered=True)

        return utils.create_success_response("Software token verified and you have successfully setup MFA")
    except ClientError as e:
        subject="Error : Verify MFA Setup"
        message=json.dumps(e.response)
        utils.developerNotification(event, subject, message)

        logger.error(e.response)
        return utils.create_error_response()

@tracer.capture_lambda_handler()
def disable_mfa(event, context):
    utils.set_header(event)

    params = json.loads(event['body'])
    access_token = params['access_token']

    requesting_user_name = event['requestContext']['authorizer']['userName']
    tracer.put_annotation(key="UserName", value=requesting_user_name)

    tenant_id = event['requestContext']['authorizer']['tenantId']
    tracer.put_annotation(key="TenantId", value=tenant_id)
    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)

    try:
        id = cognito_idp()
        id.set_user_mfa_preference(access_token, status=False, isPreffered=False)

        return utils.create_success_response("Software token MFA has disabled ")
    except ClientError as e:
        subject="Error : Disbale MFA"
        message=json.dumps(e.response)
        utils.developerNotification(event, subject, message)

        logger.error(e.response)
        return utils.create_error_response()


@tracer.capture_lambda_handler()
def forgot_password(event, context):
    utils.set_header(event)

    params = json.loads(event['body'])
    username = params['userEmail']

    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    tracer.put_annotation(key="UserName", value=username)
    isTenantLogin = False
    
    try:
        id = cognito_idp()

        if 'origin' in event['headers']:
            if event['headers']['origin'] not in site_origin:
                sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]

                print("Origin : ", event['headers']['origin'])
                if event['headers']['origin'] == 'https://cloudkida.electromech.info' :
                    sub_domain = 'cloudkida'

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

                isTenantLogin = True

        if isTenantLogin:
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)
            id.client_id = tenant_client_id

        user_data = id.admin_get_user(username)
        if user_data['UserStatus'] == 'FORCE_CHANGE_PASSWORD':
            response = id.admin_resend_password(username)
            logger.info("temporary password sent")

            body = {
                "message": f"temporary password sent to your mail",
                "action": "FORCE_CHANGE_PASSWORD"
            }

            return utils.create_success_response_cus_body(json.dumps(body))
        
        else:
            response = id.forgot_password(username)
            destination = response['CodeDeliveryDetails']['Destination']
            medium = response['CodeDeliveryDetails']['DeliveryMedium']
            
            logger.info("OTP sent for resetting password")
            return utils.create_success_response(f"OTP sent for resetting password through {medium} to {destination} ")
    
    except ClientError as e:
        logger.error(e.response)
        return utils.create_error_response()

@tracer.capture_lambda_handler()
def confirm_forgot_password(event, context):
    utils.set_header(event)

    isTenantLogin=False
    params = json.loads(event['body'])
    username = params['userEmail']
    code = params['code']
    new_password = params['new_password']

    tracer.put_annotation(key="Microservice", value=Microservice.UserManagement)
    tracer.put_annotation(key="UserName", value=username)

    try:
        id = cognito_idp()

        if 'origin' in event['headers']:
            if event['headers']['origin'] not in site_origin:
                sub_domain = event['headers']['origin'].split('.')[0].split('/')[2]

                print("Origin : ", event['headers']['origin'])
                if event['headers']['origin'] == 'https://cloudkida.electromech.info' :
                    sub_domain = 'cloudkida'

            if event['headers']['origin'] == 'https://labs.digivarsity.com' :
                sub_domain = 'digivarsity'

                isTenantLogin = True

        if isTenantLogin:
            tenant_id, tenant_pool_id, tenant_client_id, tenant_name = get_tenant_client(sub_domain)
            id.client_id = tenant_client_id

        id.confirm_forgot_password(username, code, new_password)

        return utils.create_success_response("New password has been set successfully.")
    except ClientError as e:
        logger.error(e.response)
        if e.response['Error']['Code'] == 'CodeMismatchException':
            return utils.create_error_response(e.response['Error']['Message'])
        if e.response['Error']['Code'] == 'ExpiredCodeException':
            return utils.create_error_response(e.response['Error']['Message'])
        return utils.create_error_response()



class UserInfo:
    def __init__(self, user_name=None, userId=None,tenant_id=None, user_role=None, 
    email=None, firstName=None, lastName=None, status=None, enabled=None, created=None, modified=None, addressLine=None, 
    city=None, state=None, country=None, pincode=None, mobileno=None):
        self.user_name = user_name
        self.userId = userId
        self.tenant_id = tenant_id
        self.user_role = user_role
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
        self.status = status
        self.enabled = enabled
        self.created = created
        self.modified = modified
        self.addressLine = addressLine
        self.pincode = pincode
        self.city = city
        self.state = state
        self.country = country
        self.mobileno = mobileno

TenantUserUnneccessaryInfo = {'tenant_id', 'user_role', 'status', 'enabled', 'created', 'modified', 'user_name'}

class TenantMngDB():
    """Tenant Related information"""

    client:str = boto3.client('dynamodb',  region_name=environ["region"])
    sess:str
    table_name = "ServerlessSaaS-TenantDetails"

    def get_items(self):
        response = self.client.scan(
            TableName=self.table_name,
            ProjectionExpression="tenantId, tenantName, subDomain, userPoolId, appClientId, isActive, dedicatedTenancy"
        )
        return response

class TenantInfo():
    def __init__(self, subDomain=None, apiKey=None,tenantAddress=None,tenantTier=None,tenantId=None,userPoolId=None,appClientId=None,tenantName=None,isActive=None,tenantEmail=None,apiGatewayUrl=None,tenantPhone=None,dedicatedTenancy=None):
        # self.tenantId = tenantId
        # apiKey = apiKey
        # self.tenantAddress = tenantAddress
        # tenantTier = tenantTier
        self.subDomain = subDomain
        self.userPoolId = userPoolId
        self.appClientId = appClientId
        # self.tenantName = tenantName
        self.isActive = isActive
        # self.tenantEmail = tenantEmail
        # apiGatewayUrl = apiGatewayUrl
        # self.tenantPhone = tenantPhone
        self.dedicatedTenancy = dedicatedTenancy

def to_json(dict:dict) -> json :
    return json.dumps(dict)

def get_tenant_client(sub_domain):
    tenant_mng = TenantMngDB()
    tenant_info = tenant_mng.get_items()
    if 'Items' in tenant_info and len(tenant_info['Items']) > 0:
        for tenant in tenant_info['Items']:
            if tenant['subDomain']['S'] == sub_domain:
                try:
                    tenant_id = tenant['tenantId']['S']
                    tenant_client_id = tenant['appClientId']['S']
                    tenant_pool_id = tenant['userPoolId']['S']
                    tenant_name = tenant['tenantName']['S']
                    logger.info("Tenant info fetched : {}".format(tenant_client_id))
                    # tenant['userPoolId']
                    # tenant['isActive']['BOOL']
                    # tenant['dedicatedTenancy']['BOOL']
                except KeyError:
                    continue

                return tenant_id, tenant_pool_id, tenant_client_id, tenant_name

# import re
# # re_mobileno = re.compile(r'^(([0-9]){12})|(\s{1})$')
# # re_email = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
# re_common = r'^([A-Za-z]+){3,50}$'
# # re_email = re.compile(r'^([A-Za-z0-9/,-]+){7,125}$')
# text = 'India'
# r = re.fullmatch(re_common,text)
# if r is None:
#     print("Return Error !")
# else:
#     print("OK")

# body={
#     "userName": "kartik.thummar1@electromech.info",
#     "users": [
#         'kartik.thummar1@electromech.info',
#         'kartik.thummar1@electromech.info',
#         'kartik.thummar1@electromech.info'
#     ],
#     # "filter":"",
#     "limit":"1",
#     # "pagination_token": ""
# }
# e = {
#         "body": json.dumps(body),
#         "headers" : {'accessToken': ' '},
#         "requestContext":   {
#             "authorizer" :  {
#                 "userRole": "TenantAdmin",
#                 "userName": "kartik.thummar1@electromech.info",
#                 "tenantId": "default",
#                 # "userPoolId": environ['CognitoUserPoolId']
#                 "userPoolId": "ap-south-1_wBWqV5JIH"

#             }
#         }
# }

# print(get_user(e,'c'))
# print(disable_users_all(e, 'c'))
# print(enable_users_all(e,'c'))

# event = {
#     'queryStringParameters':     {
#         "username" : "tenant-admin-dba41af971f111eca1f7eb272f1b07ff",
#         "password" : "kartik.thummar1@electromech.infoP",
#     },
#     'body' : {
#         "username": "kartik.thummar9",
#         "email": "kartik.thummar9@electromech.info",
#     },
#     "requestContext": {
#     "resourceId": "cmfhut",
#     "authorizer": {
#         "accesskey": "ASIAYIRBCUFZTOL2VLIH",
#         "secretkey": "2r8NRcBcCog68y2Sy1uxVy//NHACUyP4UNMpf0tC",
#         "apiKey": "daae9784-6d96-11eb-a28b-38f9d33cfd0f",
#         "tenantId": "dba41af971f111eca1f7eb272f1b07ff",
#         "principalId": "b8c675c1-0218-4e2b-a2ab-09e97323ffe0",
#         "integrationLatency": 2418,
#         "userName": "tenant-admin-dba41af971f111eca1f7eb272f1b07ff",
#         "userRole": "TenantAdmin",
#         "sessiontoken": "FwoGZXIvYXdzEGcaDNwdWjLbVRzQ0TQkfCK3AvFduKQx0CZ8QIusscWso/4ECoQe4MGEDZX7fNwXhy4TUQ1D8afFEi3NpsmE6sO//gPLCkFD8psL/VBzjM1koKtcrrzNJTCHDigAON/Vv4iUSVGdqgDAPra8RPYhBywAdUwDqKqkNuG/gsnq5wAQW8a1xMGQCZ4V/fwPZCEyPFiFRVxKC5uJf/kjA0liFzxfNG18tEAujS6326oBNEUpfzTB3FlzCCrcdOVuzLBAr7K8qn2/R0WAMZt2l54hF406710QnW0UWj06jdzrPL3fO5MO9+rQILDc8j6KBIHFxqhMxkSDrtkxVYnLeK17f06Y/Bb0s5Il+0j20fQ6F69FWvRyt/H1Q1R6hYy2DTeG6ueOrTIVr8yn25i/j2ha4qaoF28S3pI8F8HrCunl6VSjuZ8Gc3MNBMknKMPyrJAGMi22oD+C0kKzbAQQSGHMIiWCBoaLC8Ycmyx9jO5x7x86aBZUzwkP50vpJ0R3wjk=",
#         "userPoolId": "ap-south-1_wBWqV5JIH",
#         },
#     }
# }
# print(user_login(event, 'context'))


# print(create_user(event, 'c'))
# print(list_users(e,'c'))
# body = {
#     "firstName": "",
#     "lastName": "",
#     "userRole": "TenantAdmin",
#     "addressLine": "Ahmedabad",
#     "city": "Ahmedabad",
#     "state": "Gujarat",
#     "country": "india",
#     "pincode": "123456",
#     "mobileno": "911234567890",
#     "userEmail": "kartik.thummar7@electromech.info",
#     "password": "kartik.thummar1@electromech.infoP",
# }
# e={
#     'body': json.dumps(body),
#     'headers': {},
#     'requestContext': {
#         'authorizer': {
#             'tenantId' : 'deafult',
#             'userPoolId' : environ['CognitoUserPoolId'],
#             'userRole' : 'TenantAdmin',
#             'userName' : 'kartik.thummar1@electromech.info'
#         }
#     },
# }
# print(tenant_admin_create_user(e,"c"))
# print(user_login(e,'c'))

# print("https://dev.cloudkida.com".split('.')[0].split('/')[2])

# if True:
#     raise Exception('Unauthorized')

# body={
#     "useremail":"meet.thakkar3@electromech.info"
# }
# e={
#     'body': json.dumps(body),
#     'requestContext': {
#         'authorizer': {
#             'tenantId' : 'deafult',
#             'userRole' : 'TenantAdmin',
#             'userName' : 'kartik.thummar1@electromech.info'
#         }
#     }
# }
# print(admin_resend_user_password(e,'c'))


# body={
#     "StartTime":"2023-03-28T12:00:00.000Z",
#     "EndTime":"2023-03-28T20:00:00.000Z"
# }
# e={
#     'body': json.dumps(body),
#     'requestContext': {
#         'authorizer': {
#             'userRole' : 'TenantAdmin',
#         }
#     }
# }
# print(create_account_metric_widget(e,'c'))

# body={
#     "userEmail":"kartik.thummar7@electromech.info"
# }

# e={
#     'body': json.dumps(body),
#     'headers': {
#         'origin': 'https://dev.cloudkida.com/'
#         },
#     'requestContext': {
#         'authorizer': {
#             'tenantId' : 'dba41af971f111eca1f7eb272f1b07ff',
#             'userRole' : 'TenantAdmin',
#             'userName' : 'kartik.thummar1@electromech.info'
#         }
#     }
# }

# print(forgot_password(e,'c'))